import { LightningElement,track,wire } from 'lwc';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';

export default class SearchCase extends LightningElement {
    @track reportID;
    @track statusValue;
    @track reportTypeValue;
    @track responsibleSectionValue;
    @track staffMemberValue;
    @track nameOfInsured;
    @track OpenDate;
    @track closedDate;
    @track responsibleStaffMemeber;
    @track statusOptions;
    @track reportTypeOptions;
    @track responsibleSectionOptions;
    @wire(getPicklistValues,{
        recordTypeId: '012000000000000AAA',
        fieldApiName: 'Case.Status'
    })CaseStatusValues({error,data}){
            console.log(data);
            if(data){
                this.statusOptions=data.values;
            }else{
                console.log(JSON.stringify(error));
            }
      }
    @wire(getPicklistValues,{
        recordTypeId: '012000000000000AAA',
        fieldApiName: 'Case.Case_Classification__c'
    })CaseReportTypeValues({error,data}){
            console.log(data);
            if(data){
                this.reportTypeOptions=data.values;
            }else{
                console.log(JSON.stringify(error));
            }
      }
    @wire(getPicklistValues,{
        recordTypeId: '012000000000000AAA',
        fieldApiName: 'Case.Case_Type__c'
    })CaseResponsibleSectionValues({error,data}){
            console.log(data);
            if(data){
                this.responsibleSectionOptions=data.values;
            }else{
                console.log(JSON.stringify(error));
            }
      }
    caseChange(event) {
        if(event.target.name=='reportId'){
            this.reportID= event.target.value;
        }
        if(event.target.name=='Status'){
            this.statusValue= event.detail.value;
        }
        if(event.target.name=='reportType'){
            this.reportTypeValue= event.detail.value;
        }
        if(event.target.name=='responsibleSection'){
            this.responsibleSectionValue= event.detail.value;
        }
        if(event.target.name=='staffMember'){
            this.staffMemberValue= event.detail.value;
        }
        if(event.target.name=='nameOfInsured'){
            this.nameOfInsured= event.target.value;
        }
        if(event.target.name=='responsibleStaffMemeber'){
            this.responsibleStaffMemeber= event.target.value;
        }
        if(event.target.name=='OpenDate'){
            this.OpenDate= event.target.value;
        }
        if(event.target.name=='closedDate'){
            this.closedDate= event.target.value;
        }
    }
    handleReset(event){
        [...this.template.querySelectorAll('lightning-input'),...this.template.querySelectorAll('lightning-combobox')].forEach(element => {
            if(element.type === 'checkbox' || element.type === 'checkbox-button'){
              element.checked = false;
            }else{
              element.value = null;
            }      
          });
    }
    handleSearch(event){

    }
    handleValueSelectedOnCase(event){
        this.staffMemberValue = event.detail;
    }
}